import java.io.IOException;
import java.util.List;
 
import com.bazaarvoice.jolt.Chainr;
import com.bazaarvoice.jolt.JsonUtils;
 

public class CustomJsonTransformer {

	/*
	 * Applies predefined specifications of the JOLT-library on the given JSON data.
	 * Returns data in the right format.
	 */
	public static String formatter(String input) {
		List chainrSpecJSON = JsonUtils
				.filepathToList("/Users/arnehenzgen/Documents/workspace_new/MobilityData/specs.json");
		Chainr chainr = Chainr.fromSpec(chainrSpecJSON);
		Object inputJSON = JsonUtils.jsonToObject(input);
		Object transformedOutput = chainr.transform(inputJSON);
		return JsonUtils.toJsonString(transformedOutput);
	}
}
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

import org.apache.commons.io.IOUtils;

public class IndexKorrektur {

	/*
	 * Takes given data and replaces every bliblablub with an incrementing index. 
	 * Writes data back to local file.
	 */
	public static void main(String[] args) throws IOException {
		String query = "";
		FileReader inputStream = new FileReader("Output1.json");
		try {
			query += IOUtils.toString(inputStream);
		} finally {
			inputStream.close();
		}
		for (int i = 0; i < query.length(); i++) {
			query.replaceFirst("bliblablub", "" + i + "");
		}
		System.out.println("Fertig");
		try (Writer writer = new FileWriter("Output1.json")) {
			writer.write(query);
		} catch (Exception e) {
		}

	}
}

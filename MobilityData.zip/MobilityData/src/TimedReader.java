import java.util.Timer;

public class TimedReader {

	/*
	 * Downloads data from vbb-query by starting run()-method of class Reader
	 * every 10 minutes.
	 */
	public static void main(String[] args) {
		Timer reader = new Timer();
		reader.schedule(new Reader(), 0, 600000);
	}
}

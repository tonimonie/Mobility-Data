import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

import org.apache.commons.io.IOUtils;

public class IndexKorrektur {

	/*
	 * Takes given data and replaces every platzhalter with an incrementing index. 
	 * Writes data back to local file.
	 */
	public static void main(String[] args) throws IOException {
		
		String query = "";
		FileReader inputStream = new FileReader("Nr4.json");
		try {
			query += IOUtils.toString(inputStream);
		} finally {
			inputStream.close();
		}
		
		for (int i = 62000; i < 100000; i++) {
			query = query.replaceFirst("platzhalter", "" + i + "");
			if ((i % 1000) == 0)
				System.out.println(i);
		}
		query = query.replace("\"timestamp\":\"", "\"timestamp\":\"2018-07-13T");
		System.out.println("Fertig");
		try (Writer writer = new FileWriter("Nr4.json")) {
			writer.write(query);
		} catch (Exception e) {
		}

	}
}

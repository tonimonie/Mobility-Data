import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.Writer;
import java.net.URL;
import java.util.TimerTask;
import org.apache.commons.io.IOUtils;

public class Reader extends TimerTask {
	
	/*
	 * Patterns to format the latitude/longitude-coordinates with a dot after
	 * the second number.
	 */
	String patternlat = "\"lat\":\"([0-9][0-9])";
	String patternlat1 = "\"lat\":\"52.";
	String patternlon = "\"lon\":\"([0-9][0-9])";
	String patternlon1 = "\"lon\":\"13.";
	
	
	/*
	 * Gives the data from the vbb-query to the CustomJsonTransformer to format it in the right way.
	 * Then add an index line before each json entry to fit to the Bulk-API.
	 * Then use the latitude/longitude-patterns to format the coordinates.
	 * At last add new lines.
	 */
	public void run() {

		try {
			String query = "";
			FileReader inputStream = new FileReader("Nr4.json");

			try {
				query += IOUtils.toString(inputStream);
			} finally {
				inputStream.close();
			}

			try (Writer writer = new FileWriter("Nr4.json")) {
				query += CustomJsonTransformer.formatter(readUrl("http://fahrinfo.vbb.de/bin/query.exe/dny?look_minx=13"
						+ "000000&look_maxx=13999999&look_miny=52000000&look_maxy=52999999&tpl=trains2json2&loo"
						+ "k_productclass=127&look_json=no&performLocating=1&look_nv=zugposmode|2|interval|30000"
						+ "|intervalstep|2000|"));
				query = query.replace("{\"t\":[", "{\"index\":{\"_index\":\"output\",\"_id\":platzhalter}}\r\n");
				query = query.replace("]},", "]}\r\n{\"index\":{\"_index\":\"output\",\"_id\":platzhalter}}\r\n");
				query = query.substring(0, query.length() - 2);
				query = query.replaceAll(patternlat, patternlat1);
				query = query.replaceAll(patternlon, patternlon1);
				writer.write(query + "\r\n");
			}
		} catch (Exception e) {
		}
	}
	
	/*
	 * Returns the data of the given vbb-query as a string.
	 */
	private static String readUrl(String urlString) throws Exception {
		BufferedReader reader = null;
		String line = null;

		try {
			URL url = new URL(urlString);
			reader = new BufferedReader(new InputStreamReader(url.openStream()));
			StringBuffer buffer = new StringBuffer();
			while ((line = reader.readLine()) != null)
				buffer.append(line);
			return buffer.toString();
		} finally {
			if (reader != null)
				reader.close();
		}

	}

}